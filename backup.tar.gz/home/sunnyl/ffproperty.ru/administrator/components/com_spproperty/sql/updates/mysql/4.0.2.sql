-- v4.0.2

--  Update Structure for #__spproperty_visitrequests --
ALTER TABLE `#__spproperty_visitrequests` CHANGE `userid` `userid` BIGINT(20) NOT NULL DEFAULT '0';