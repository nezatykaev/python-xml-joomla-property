#
#<?php die('Forbidden.'); ?>
#Date: 2024-08-27 21:33:53 UTC
#Software: Joomla! 4.4.8 Stable [ Pamoja ] 27-August-2024 16:00 GMT

#Fields: datetime	priority clientip	category	message
2024-08-27T21:33:53+00:00	INFO 95.24.71.58	joomlafailure	Username and password do not match or you do not have an account yet.
2024-08-28T12:18:09+00:00	INFO 94.243.140.154	joomlafailure	Username and password do not match or you do not have an account yet.
2024-08-30T10:39:09+00:00	INFO 94.243.140.154	joomlafailure	Username and password do not match or you do not have an account yet.
2024-08-30T10:39:12+00:00	INFO 94.243.140.154	joomlafailure	Username and password do not match or you do not have an account yet.
2024-08-31T09:43:59+00:00	INFO 47.56.110.204	joomlafailure	Username and password do not match or you do not have an account yet.
2024-09-01T03:01:29+00:00	INFO 195.2.71.197	joomlafailure	Username and password do not match or you do not have an account yet.
2024-09-01T15:09:54+00:00	INFO 84.54.47.198	joomlafailure	Username and password do not match or you do not have an account yet.
2024-09-03T11:00:09+00:00	INFO 84.54.47.198	joomlafailure	Username and password do not match or you do not have an account yet.
2024-09-03T12:33:40+00:00	INFO 178.255.47.159	joomlafailure	Username and password do not match or you do not have an account yet.
